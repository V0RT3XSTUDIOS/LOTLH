=================================================
README - Leyends Of The Lost Heroes
===================================================

>> General Information:
Game Title: Leyends Of The Lost Heroes v1.7
Version: 1.0
Author: Diego Abimael Hernandez Moreno "V0RT3X" / Rodrigo Jesus Serrano Garcia "R0y"
Language: Python 3.x
Dependencies: Standard Python libraries (os, random, time, sys)

---------------------------------------------
>> Running Instructions:
1. Make sure you have Python installed (3.8 or higher).
2. Run the LOTLH.py file from your terminal or IDE.
> python LOTLH.py
3. Follow the on-screen instructions to create your character and begin the adventure.

---------------------------------------------
>> Technical Description:
- Console RPG with maze-like exploration (WASD).
- Combat system with skills, weapons, and enemies with basic AI.
- Branching narrative and multiple endings based on player decisions.
- Leveling system, racial progression, classes, inventory, and guild.
- Procedurally generated mazes with traps and enemies.
- Mini-bosses and area bosses.
- Citadel with market and guild management.
- DEBUG mode can be activated with a secret code.

---------------------------------------------
>> DEBUG MODE Credentials:
Character Name: V0RT3X
Passcode: X9-Ω-D347H

>> Actions Available in DEBUG Mode:
1. Level Up Manually
2. Restore Health and Mana
3. Add Gold
4. Craft Custom Weapons
5. Obtain Special Potions
6. Modify Stats
7. Toggle Invincibility
8. Skip to the Final Boss
9. Unlock All Areas
10. Test Advanced OOP Patterns

**Note:** This mode is designed for internal testing and is not recommended for normal play.

---------------------------------------------
>> Final Notes:
- The game saves its state in memory only.
- Does not require an internet connection.
- Can be extended to include save games and external files.
- Compatible with Windows, macOS, and Linux.

Thank you for playing and enjoying Legends Of The Lost Heroes!