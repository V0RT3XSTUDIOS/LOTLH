# LOTLH V1.7
# A text adventure made by Diego Abimael Hernandez Moreno "V0RT3X"
# and Rodrigo Jesus Serrano Garcia "R0y"

import os
import random
import time
import sys

# --- GLOBAL SETTINGS ---
MAX_LEVEL = 150
EVOL_LEVEL1 = 50
EVOL_LEVEL2 = 75
RECOVERY_PER_LEVEL = 2
FLOORS_PER_AREA = 5

# --- UTILITIES ---
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def wait_key():
    input("\nPress ENTER to continue...")


def print_ascii_art(text):
    print("=" * (len(text) + 4))
    print(f"| {text} |")
    print("=" * (len(text) + 4))

# --- ADVANCED OOP BLOCK ---
class Race:
    def __init__(self, name):
        self.name = name

    def evolve(self, level):
        if level >= EVOL_LEVEL2:
            return "Ultimate Form"
        elif level >= EVOL_LEVEL1:
            return "Intermediate Form"
        else:
            return "Initial Form"


class Human(Race):
    def __init__(self):
        super().__init__("Human")

    def unique_skill(self):
        return "Advanced Diplomacy"


class Elf(Race):
    def __init__(self):
        super().__init__("Elf")

    def unique_skill(self):
        return "Night Vision"


class Dwarf(Race):
    def __init__(self):
        super().__init__("Dwarf")

    def unique_skill(self):
        return "Expert Mining"


class AchievementMixin:
    def __init__(self):
        self.achievements = []

    def add_achievement(self, achievement):
        self.achievements.append(achievement)

    def show_achievements(self):
        print("\n--- Achievements Unlocked ---")
        if not self.achievements:
            print("You have no achievements yet.")
        else:
            for a in self.achievements:
                print(f"- {a}")


class Character:
    character_counter = 0

    def __init__(self, name, object_race, object_class):
        Character.character_counter += 1
        self.invincible = False  # Only enabled in debug mode
        self.name = name
        self.race = object_race
        self.class_ = object_class
        self.level = 1
        self._xp = 0
        self.__gold = 100
        self.max_health = 100
        self.health = 100
        self.max_mana = 50
        self.mana = 50
        self.inventory = []
        self.weapons = []
        self.race_status = self.race.evolve(self.level)
        self.skills = self.class_.get_skills(self.level)
        self.kills = 0

    @property
    def xp(self):
        return self._xp

    @xp.setter
    def xp(self, amount):
        if amount < 0:
            amount = 0
        self._xp = amount

    @property
    def gold(self):
        return self.__gold

    @gold.setter
    def gold(self, amount):
        if amount < 0:
            amount = 0
        self.__gold = amount

    def gain_xp(self, amount):
        self.xp += amount
        while self.xp >= self.level * 20 and self.level < MAX_LEVEL:
            self.xp -= self.level * 20
            self.level += 1
            self.race_status = self.race.evolve(self.level)
            self.skills = self.class_.get_skills(self.level)
            self.max_health += RECOVERY_PER_LEVEL
            self.health = self.max_health
            self.max_mana += RECOVERY_PER_LEVEL
            self.mana = self.max_mana
            print(f"You have reached level {self.level}! Increased health and mana.")

    def heal(self, amount):
        self.health = min(self.health + amount, self.max_health)

    def recover_mana(self, amount):
        self.mana = min(self.mana + amount, self.max_mana)

    def take_damage(self, amount):
        if hasattr(self, "invincible") and self.invincible:
            print("[DEBUG] You are invincible. You ignore damage.")
            return
        self.health -= amount
        if self.health < 0:
            self.health = 0

    def is_alive(self):
        return self.health > 0

    def add_weapon(self, weapon):
        if weapon.allowed_class and self.class_.name.lower() in weapon.allowed_class:
            self.weapons.append(weapon)
            print(f"You have obtained the weapon: {weapon.name}")
        else:
            print(f"You cannot use the weapon {weapon.name} with your class.")

    def show_backpack(self):
        print("\n--- Backpack (Weapons) ---")
        if not self.weapons:
            print("Empty")
        else:
            for i, weapon in enumerate(self.weapons, 1):
                print(f"{i}. {weapon}")
        print("\n--- Inventory (Objects) ---")
        if not self.inventory:
            print("Empty")
        else:
            for i, obj in enumerate(self.inventory, 1):
                print(f"{i}. {obj.name}")


class HeroCharacter(Character, AchievementMixin):
    def __init__(self, name, obj_race, obj_class):
        Character.__init__(self, name, obj_race, obj_class)
        AchievementMixin.__init__(self)

    def __gt__(self, other):
        return self.level > other.level  # ✅ Operator overloading >


class CharacterInspector(Character):
    def show_info(self):
        print(f"[Public] Health: {self.health}")
        print(f"[Protected] XP: {self._xp}")
        try:
            print(f"[Private] Gold: {self.__gold}")
        except AttributeError:
            print("[Private] Gold: Cannot be accessed directly (is private)")
        print(f"[Private with name mangling] Gold accessed: {self._Character__gold}")

# === REMAINING CLASSES ===
class Class:
    def __init__(self, name, skills):
        self.name = name
        self.base_skills = skills

    def get_skills(self, level):
        skills = {}
        for name, req in self.base_skills.items():
            if level >= req:
                skills[name] = f"Available from level {req}"
        return skills


class Object:
    def __init__(self, name, description, effect):
        self.name = name
        self.description = description
        self.effect = effect

    def use(self, character):
        print(f"You use {self.name}: {self.description}")
        self.effect(character)


class Weapon:
    def __init__(self, name, type_, allowed_class, damage_min, damage_max):
        self.name = name
        self.type = type_
        self.allowed_class = allowed_class
        self.damage_min = damage_min
        self.damage_max = damage_max

    def get_danio(self):
        return random.randint(self.damage_min, self.damage_max)

    def __str__(self):
        return f"{self.name} ({self.type}, Damage: {self.damage_min}-{self.damage_max})"


class Enemy:
    def __init__(self, name, health, damage, xp, is_boss=False):
        self.name = name
        self.health = health
        self.max_health = health
        self.damage = damage
        self.xp = xp
        self.is_boss = is_boss

    def is_alive(self):
        return self.health > 0

    def take_damage(self, amount):
        self.health -= amount
        if self.health < 0:
            self.health = 0

    def attack(self, player):
        actual_damage = random.randint(self.damage - 3, self.damage + 3)
        print(f"{self.name} attacks, dealing {actual_damage} of damage.")
        player.take_damage(actual_damage)

class GuildMember:
    def __init__(self, name, level):
        self.name = name
        self.level = level

    def __str__(self):
        return f"{self.name} (Lv {self.level})"


class Guild:
    def __init__(self):
        self.members = []

    def recruit(self, member):
        self.members.append(member)
        print(f"You have recruited {member.name} (Lv {member.level}) into your guild.")

    def expel(self, name):
        for m in self.members:
            if m.name.lower() == name.lower():
                self.members.remove(m)
                print(f"You have expelled {m.name} from the guild.")
                return
        print("There is no member with that name in your guild.")

    def show(self):
        print("\n--- Guild Members ---")
        if not self.members:
            print("Your guild is empty.")
        else:
            for m in self.members:
                print(f"- {m}")

class Maze:
    def __init__(self, area_name, current_floor):
        self.area_name = area_name
        self.current_floor = current_floor
        self.width = random.randint(10 + current_floor, 14 + current_floor * 2)
        self.height = random.randint(8 + current_floor, 12 + current_floor * 2)
        self.map = [['#' for _ in range(self.width)] for _ in range(self.height)]
        self.player_pos = (1, 1)
        self.exit_pos = (self.height - 2, self.width - 2)
        self.generate_map()

    def generate_map(self):
        # Step 1: Fill everything with default walls
        for y in range(self.height):
            for x in range(self.width):
                self.map[y][x] = '#'

        # Step 2: Fill the interior with paths, with an 85% chance of being walkable
        for y in range(1, self.height - 1):
            for x in range(1, self.width - 1):
                self.map[y][x] = ' ' if random.random() < 0.85 else '#'

        # Step 3: Create a guaranteed path from player to exit
        y, x = self.player_pos
        while y < self.exit_pos[0]:
            y += 1
            self.map[y][x] = ' '
        while x < self.exit_pos[1]:
            x += 1
            self.map[y][x] = ' '

        # Step 4: Place player and exit
        self.map[self.player_pos[0]][self.player_pos[1]] = 'P'
        self.map[self.exit_pos[0]][self.exit_pos[1]] = 'S'

        # Step 5: Add traps on traversable cells
        for _ in range(random.randint(2, 4)):
            while True:
                ty, tx = random.randint(1, self.height - 2), random.randint(1, self.width - 2)
                if self.map[ty][tx] == ' ':
                    self.map[ty][tx] = 'T'
                    break

        # Step 6: Add enemies on traversable cells
        for _ in range(random.randint(3, 6)):
            while True:
                ey, ex = random.randint(1, self.height - 2), random.randint(1, self.width - 2)
                if self.map[ey][ex] == ' ':
                    self.map[ey][ex] = 'E'
                    break

    def show(self):
        print(f"\nArea: {self.area_name.title()} | Floor {self.current_floor}")
        for row in self.map:
            print(''.join(row))

class Maze:
    def __init__(self, area_name, current_floor):
        self.area_name = area_name
        self.current_floor = current_floor
        self.width = random.randint(10 + current_floor, 14 + current_floor * 2)
        self.height = random.randint(8 + current_floor, 12 + current_floor * 2)
        self.map = [['#' for _ in range(self.width)] for _ in range(self.height)]
        self.player_pos = (1, 1)
        self.exit_pos = (self.height - 2, self.width - 2)
        self.generate_map()

    def generate_map(self):
        # Step 1: Fill everything with default walls
        for y in range(self.height):
            for x in range(self.width):
                self.map[y][x] = '#'

        # Step 2: Fill the interior with paths, with an 85% chance of being walkable
        for y in range(1, self.height - 1):
            for x in range(1, self.width - 1):
                self.map[y][x] = ' ' if random.random() < 0.85 else '#'

        # Step 3: Create a guaranteed path from player to exit
        y, x = self.player_pos
        while y < self.exit_pos[0]:
            y += 1
            self.map[y][x] = ' '
        while x < self.exit_pos[1]:
            x += 1
            self.map[y][x] = ' '

        # Step 4: Place player and exit
        self.map[self.player_pos[0]][self.player_pos[1]] = 'P'
        self.map[self.exit_pos[0]][self.exit_pos[1]] = 'S'

        # Step 5: Add traps on traversable cells
        for _ in range(random.randint(2, 4)):
            while True:
                ty, tx = random.randint(1, self.height - 2), random.randint(1, self.width - 2)
                if self.map[ty][tx] == ' ':
                    self.map[ty][tx] = 'T'
                    break

        # Step 6: Add enemies on traversable cells
        for _ in range(random.randint(3, 6)):
            while True:
                ey, ex = random.randint(1, self.height - 2), random.randint(1, self.width - 2)
                if self.map[ey][ex] == ' ':
                    self.map[ey][ex] = 'E'
                    break

    def show(self):
        print(f"\nArea: {self.area_name.title()} | Floor {self.current_floor}")
        for row in self.map:
            print(''.join(row))
            
class History:
    def __init__(self):
        self.visited_areas = {}

    def register_visit(self, area):
        if area not in self.visited_areas:
            self.visited_areas[area] = True
            self.event_area(area)

    def event_area(self, area):
        print(f"\nUpon first entering {area.title()}, a unique event occurs...")
        if area == "forest":
            print("The Forest whispers ancient secrets among the trees.")
        elif area == "dungeon":
            print("The shadows seem to move of their own accord.")
        elif area == "stronghold":
            print("The Stronghold rumbles with echoes of battle.")
        elif area == "archives":
            print("Forbidden truths lurk on the shelves.")
        elif area == "parish":
            print("Broken chants echo beneath cracked ceilings.")
        wait_key()

    def all_completed(self):
        return len(self.visited_areas) >= 5


def combat(player, enemy):
    print(f"\nYou are facing {enemy.name} (Health: {enemy.health}/{enemy.max_health})!")
    while enemy.is_alive() and player.is_alive():
        print(f"\n{player.name} (Health: {player.health}/{player.max_health}, Mana: {player.mana}/{player.max_mana})")
        print(f"{enemy.name} (Health: {enemy.health}/{enemy.max_health})")
        print("1. Attack with weapon\n2. Use ability\n3. Drink potion\n4. Flee")
        action = input("> ")

        if action == "1":
            if player.weapons:
                weapon = player.weapons[0]
                damage = weapon.get_danio()
                print(f"You attack with {weapon.name}, dealing {damage}.")
                enemy.take_damage(damage)
            else:
                print("You have no weapons!")

        elif action == "2":
            if player.skills:
                print("\n--- Available skills ---")
                skills_list = list(player.skills.items())
                for i, (name, desc) in enumerate(skills_list, 1):
                    print(f"{i}. {name} - {desc}")
                choice = input("Choose a skill > ")
                if choice.isdigit() and 1 <= int(choice) <= len(skills_list):
                    skill = skills_list[int(choice) - 1][0]
                    mana_cost = 10
                    if player.mana >= mana_cost:
                        player.mana -= mana_cost
                        damage = random.randint(15, 25) + player.level
                        print(f"You use {skill}, dealing {damage} magic damage.")
                        enemy.take_damage(damage)
                    else:
                        print("You don't have enough mana.")
                else:
                    print("Invalid selection.")
            else:
                print("You have no abilities unlocked yet.")

        elif action == "3":
            if player.inventory:
                item = player.inventory.pop(0)
                item.use(player)
            else:
                print("You have no potions.")

        elif action == "4":
            print("You escape combat!")
            return False

        else:
            print("Invalid choice.")

        if enemy.is_alive():
            enemy.attack(player)

        if not player.is_alive():
            print(f"You have been defeated by {enemy.name}!")
            player.kills += 1
            player.health = player.max_health // 2
            player.mana = player.max_mana // 2
            return False

    if not enemy.is_alive():
        print(f"You have defeated {enemy.name}!")
        player.gain_xp(enemy.xp)
        random_drop(player, enemy)
        return True


def random_drop(player, enemy):
    prob = random.random()
    if prob < 0.3:
        potion_effect = lambda p: p.heal(30)
        potion = Object("Health Potion", "Heals 30 health points.", potion_effect)
        player.inventory.append(potion)
        print(f"{enemy.name} dropped a Health Potion.")
    elif prob < 0.6:
        types = ["sword", "axe", "staff"]
        weapon_type = random.choice(types)
        allowed_class = ["warrior"] if weapon_type in ["sword", "axe"] else ["mage"]
        damage_min = random.randint(5, 10) + player.level // 3
        damage_max = damage_min + random.randint(5, 10)
        weapon = Weapon(f"{weapon_type.capitalize()} mysterious", weapon_type, allowed_class, damage_min, damage_max)
        player.add_weapon(weapon)
    else:
        gold_found = random.randint(10, 30) + enemy.xp // 2
        player.gold += gold_found
        print(f"You find {gold_found} gold coins.")

def explore_area(player, area, story):
    current_floor = 1
    while current_floor <= FLOORS_PER_AREA:
        lab = Maze(area, current_floor)

        while True:
            clear_screen()
            lab.show()
            print(f"\n{player.name} | HP: {player.health}/{player.max_health} | Mana: {player.mana}/{player.max_mana} | Gold: {player.gold}")
            print("Use W/A/S/D to move. (Q to return to the Citadel)")
            mov = input("> ").lower()

            y, x = lab.player_pos
            ny, nx = y, x

            if mov == "w" and y > 1:
                ny -= 1
            elif mov == "s" and y < lab.height - 2:
                ny += 1
            elif mov == "a" and x > 1:
                nx -= 1
            elif mov == "d" and x < lab.width - 2:
                nx += 1
            elif mov == "q":
                print("You return to the Citadel.")
                return
            else:
                continue

            cell = lab.map[ny][nx]

            # Only move if the cell is not a wall
            if cell not in [' ', 'E', 'T', 'S']:
                continue  # If it's a wall or something else, don't move

            # Restore the previous cell if it was the exit
            if (y, x) == lab.exit_pos:
                lab.map[y][x] = 'S'
            else:
                lab.map[y][x] = ' '

            # Move the player
            lab.player_pos = (ny, nx)
            lab.map[ny][nx] = 'P'

            if cell == 'E':
                level = current_floor + random.randint(0, player.level)
                hp = 30 + level * 5
                damage = 5 + level * 2
                xp = 10 + level * 3
                enemy = Enemy(f"{area.title()} beast Lv{level}", hp, damage, xp)
                survived = combat(player, enemy)
                if not survived:
                    print("You return to the Citadel badly wounded.")
                    return
            elif cell == 'T':
                trap_damage = random.randint(5, 15)
                player.take_damage(trap_damage)
                print(f"\nYou have activated a trap! You lose {trap_damage} of life.")
                if not player.is_alive():
                    print("The trap was lethal. You wake up wounded in the Citadel.")
                    player.deaths += 1
                    player.health = player.max_health // 2
                    player.mana = player.max_mana // 2
                    return
                wait_key()
            elif cell == 'S':
                print(f"\n[+] You've found the exit from floor {current_floor}!")
                wait_key()
                current_floor += 1
                break

        # Mini-boss encounter halfway through the floors
        if current_floor == FLOORS_PER_AREA // 2:
            boss = Enemy(f"{area.title()} Guard", 80 + player.level * 4, 15 + player.level // 2, 50)
            print(f"\nA mini-boss is blocking your way!")
            survived = combat(player, boss)
            if not survived or not player.is_alive():
                print("You escape wounded towards the Citadel...")
                return

    # Final Boss after all floors are completed
    if current_floor > FLOORS_PER_AREA:
        final_boss_area = Enemy(f"Lord of {area.title()}", 120 + player.level * 5, 18 + player.level // 2, 100, is_boss=True)
        print(f"\nYou reach the heart of {area.title()}! You face the final boss.")
        survived = combat(player, final_boss_area)
        if not survived or not player.is_alive():
            print("You barely survive and crawl back to the Citadel...")
            return

    print(f"\nYou have completed all exploration of area {area.title()}!")
    wait_key()

def citadel(player, guild):
    while True:
        print("\n--- Citadel ---")
        print("1. Rest\n2. Trade\n3. Manage the guild\n4. View achievements\n5. Leave the Citadel")
        option = input("> ")
        if option == "1":
            player.health = player.max_health
            player.mana = player.max_mana
            print("You rest and fully recover.")
        elif option == "2":
            trade(player)
        elif option == "3":
            manage_guild(player, guild)
        elif option == "4":
            player.show_achievements()
        elif option == "5":
            break
        else:
            print("Invalid option.")

def trade(player):
    while True:
        print("\n--- Trade ---")
        print(f"You have {player.gold} gold coins.")
        print("1. Buy health potion (30 gold)\n2. Quit")
        option = input("> ")
        if option == "1":
            if player.gold >= 30:
                potion_effect = lambda p: p.heal(30)
                potion = Object("Health Potion", "Heals 30 points.", potion_effect)
                player.inventory.append(potion)
                player.gold -= 30
                print("You bought a Health Potion.")
            else:
                print("You don't have enough gold.")
        elif option == "2":
            break
        else:
            print("Invalid option.")

def manage_guild(player, guild):
    while True:
        print("\n--- Guild Management ---")
        print("1. See members\n2. Recruit new member\n3. Kick member\n4. Back")
        choice = input("> ")
        if choice == "1":
            guild.show()
        elif choice == "2":
            names = ["Einar", "Lyra", "Thorn", "Seraphine", "Doran", "Kael"]
            new = GuildMember(random.choice(names) + str(random.randint(1, 99)), random.randint(1, player.level))
            guild.recruit(new)
        elif choice == "3":
            kick_name = input("Name of member to kick: ")
            guild.expel(kick_name)
        elif choice == "4":
            break
        else:
            print("Invalid choice.")

def final_boss(player, guild, story):
    print("\nKing Ornstein awaits you at the top of the world...")
    ornstein = Enemy("King Ornstein", 160 + player.level * 4, 15 + player.level // 3, 250, is_boss=True)
    survived = combat(player, ornstein)

    if not survived or not player.is_alive():
        print("Ornstein defeats you and darkness consumes the world...")
        wait_key()
        sys.exit()

    set_end(player, guild, story)
    wait_key()
    sys.exit()

def set_end(player, guild, story):
    print("\n--- Epilogue ---")
    if player.deaths >= 3:
        print("So many deaths corrupted your soul. You save the world, but you become a shadow.")
    elif len(guild.members) >= 5:
        print("With your mighty guild, you found a kingdom. Peace comes, beneath your relentless banner.")
    elif player.deaths == 0 and player.health > player.max_health * 0.8:
        print("You are the hero of prophecy. The world flourishes and your legend lives on forever.")
    else:
        print("You bring balance, but the world's scars will remain forever.")
    print("Thank you for playing Legends Of The Lost Heroes!")

def enable_debug(player, story, guild):
    print("*** SECRET DEBUG MODE ENABLED ***")
    while True:
        print("Debug Options:")
        print("1. Level Up")
        print("2. Restore Health and Mana")
        print("3. Add Gold")
        print("4. Add weapon")
        print("5. Add potion")
        print("6. View/modify stats")
        print("7. Toggle invincibility")
        print("8. Skip to final boss")
        print("9. Unlock all areas")
        print("10. Exit debug mode")
        print("11. Test advanced OOP patterns")
        option = input("DEBUG > ")

        if option == "1":
            levels = int(input("How many levels do you want to go up? > "))
            player.gain_xp(player.level * 20 * levels)

        elif option == "2":
            player.health = player.max_health
            player.mana = player.max_mana
            print("Life and mana restored.")

        elif option == "3":
            gold = int(input("How much gold do you want to add? > "))
            player.gold += gold
            print(f"{gold} gold coins were added.")

        elif option == "4":
            name = input("Weapon name > ")
            type_ = input("Type (sword/axe/staff) > ")
            class_ = input("Allowed class (warrior/mage) > ").lower()
            dmin = int(input("Minimum damage > "))
            dmax = int(input("Maximum Damage > "))
            weapon = Weapon(name, type_, [class_], dmin, dmax)
            player.add_weapon(weapon)

        elif option == "5":
            potion_effect = lambda p: p.heal(999)
            potion = Object("MegaPotion", "Restores all health.", potion_effect)
            player.inventory.append(potion)
            print("A MegaPotion was added to the inventory.")

        elif option == "6":
            print(f"Level: {player.level}, XP: {player.xp}, Kills: {player.kills}, HP: {player.health}/{player.max_health}")
            stat = input("What do you want to modify? (level/xp/health/kills/none) > ").lower()
            if stat == "level":
                player.level = int(input("New level > "))
            elif stat == "xp":
                player.xp = int(input("New XP > "))
            elif stat == "health":
                player.health = int(input("New health > "))
            elif stat == "kills":
                player.kills = int(input("Number of kills > "))

        elif option == "7":
            player.invincible = not player.invincible
            state = "ON" if player.invincible else "OFF"
            print(f"Invincible mode: {state}")

        elif option == "8":
            print("Jumping directly to the final boss...")
            final_boss(player, guild, story)
            break

        elif option == "9":
            for area in ["forest", "dungeon", "stronghold", "archives", "parish"]:
                story.register_visit(area)
            print("All areas marked as completed.")

        elif option == "10":
            print("Exiting debug mode...")
            break

        elif option == "11":
            print("\n=== ADVANCED OOP PATTERN TESTING ===")
            print(f"Created characters: {Character.character_counter}")
            inspector = CharacterInspector(player.name, player.race, player.class_)
            inspector.show_info()
            dummy = HeroCharacter("Dummy", Human(), Class("Warrior", {}))
            if player > dummy:
                print(f"{player.name} is higher than Dummy.")
            else:
                print(f"{player.name} is NOT higher than Dummy.")
        else:
            print("Invalid option.")

def main():
    clear_screen()
    print_ascii_art("Welcome to Legends Of The Lost Heroes")
    name = input("What is your name, adventurer? > ")
    debug_mode = False
    if name == "V0RT3X" and input("Do you have a code? > ") == "X9-Ω-D347H":
        debug_mode = True

    # Choose race
    while True:
        print("Choose your race: 1. Human 2. Elf 3. Dwarf")
        r = input("> ")
        if r == "1":
            race = Human()
            break
        elif r == "2":
            race = Elf()
            break
        elif r == "3":
            race = Dwarf()
            break
        else:
            print("Invalid choice.")

    # Choose class
    while True:
        print("Choose your class: 1. Warrior 2. Mage")
        c = input("> ")
        if c == "1":
            class_ = Class("Warrior", {"Mighty Strike": 1, "Whirlwind": 10})
            break
        elif c == "2":
            class_ = Class("Mage", {"Fireball": 1, "Arcane Storm": 10})
            break
        else:
            print("Invalid option.")

    player = HeroCharacter(name, race, class_)
    story = History()
    guild = Guild()

    if debug_mode:
        enable_debug(player, story, guild)

    # Starting weapon
    if class_.name.lower() == "warrior":
        player.add_weapon(Weapon("Rusty Sword", "sword", ["warrior"], 5, 10))
    elif class_.name.lower() == "mage":
        player.add_weapon(Weapon("Used Staff", "staff", ["mage"], 4, 9))
    print(f"You have received your {player.weapons[0].name} to start.")

    # Main menu loop
    areas = ["forest", "dungeon", "stronghold", "archives", "parish"]
    while True:
        print("\n--- MAIN MENU ---")
        print("1. Explore an area\n2. Go to the Citadel\n3. View backpack\n4. Exit")
        op = input("> ")
        if op == "1":
            print("\nAvailable areas:")
            for i, a in enumerate(areas, 1):
                print(f"{i}. {a.title()}")
            e = input("Choose an area by number: ")
            if e.isdigit() and 1 <= int(e) <= len(areas):
                area = areas[int(e) - 1]
                story.register_visit(area)
                explore_area(player, area, story)
            else:
                print("Invalid selection.")
        elif op == "2":
            citadel(player, guild)
        elif op == "3":
            player.show_backpack()
        elif op == "4":
            print("See you soon, adventurer!")
            break
        else:
            print("Invalid choice.")

        if story.all_completed():
            final_boss(player, guild, story)
            break


if __name__ == "__main__":
    main()
