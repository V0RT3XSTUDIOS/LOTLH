#LOTLH V1.7
#A text adventure made by Diego Abimael Hernandez Moreno "V0RT3X" and Rodrigo Jesus Serrano Garcia "R0y"

import os
import random
import time
import sys

# --- CONFIGURACIÓN GLOBAL ---
NIVEL_MAXIMO = 150
NIVEL_EVOL1 = 50
NIVEL_EVOL2 = 75
RECUPERACION_POR_NIVEL = 2
PISOS_POR_AREA = 5

# --- UTILIDADES ---
def limpiar_pantalla():
    os.system('cls' if os.name == 'nt' else 'clear')

def esperar_tecla():
    input("\nPresiona ENTER para continuar...")

def imprimir_ascii_art(text):
    print("=" * (len(text) + 4))
    print(f"| {text} |")
    print("=" * (len(text) + 4))

# --- BLOQUE OOP AVANZADO ---
class Raza:
    def __init__(self, nombre):
        self.nombre = nombre
    def evolucionar(self, nivel):
        if nivel >= NIVEL_EVOL2:
            return "Forma Suprema"
        elif nivel >= NIVEL_EVOL1:
            return "Forma Intermedia"
        else:
            return "Forma Inicial"

class Humano(Raza):
    def __init__(self):
        super().__init__("Humano")
    def habilidad_unica(self):
        return "Diplomacia Avanzada"

class Elfo(Raza):
    def __init__(self):
        super().__init__("Elfo")
    def habilidad_unica(self):
        return "Visión Nocturna"

class Enano(Raza):
    def __init__(self):
        super().__init__("Enano")
    def habilidad_unica(self):
        return "Minería Experta"

class LogroMixin:
    def __init__(self):
        self.logros = []
    def agregar_logro(self, logro):
        self.logros.append(logro)
    def mostrar_logros(self):
        print("\n--- Logros Desbloqueados ---")
        if not self.logros:
            print("Aún no tienes logros.")
        else:
            for l in self.logros:
                print(f"- {l}")

class Personaje:
    contador_personajes=0
    def __init__(self, nombre, raza_obj, clase_obj):
        Personaje.contador_personajes +=1
        self.invencible = False  # Solo activado por el modo debug
        self.nombre = nombre
        self.raza = raza_obj
        self.clase = clase_obj
        self.nivel = 1
        self._xp = 0
        self.__oro = 100
        self.vida_max = 100
        self.vida = 100
        self.mana_max = 50
        self.mana = 50
        self.inventario = []
        self.armas = []
        self.estado_raza = self.raza.evolucionar(self.nivel)
        self.habilidades = self.clase.obtener_habilidades(self.nivel)
        self.muertes = 0

    @property
    def xp(self):
        return self._xp
    @xp.setter
    def xp(self, cantidad):
        if cantidad < 0:
            cantidad = 0
        self._xp = cantidad

    @property
    def oro(self):
        return self.__oro
    @oro.setter
    def oro(self, cantidad):
        if cantidad < 0:
            cantidad = 0
        self.__oro = cantidad

    def ganar_xp(self, cantidad):
        self.xp += cantidad
        while self.xp >= self.nivel * 20 and self.nivel < NIVEL_MAXIMO:
            self.xp -= self.nivel * 20
            self.nivel += 1
            self.estado_raza = self.raza.evolucionar(self.nivel)
            self.habilidades = self.clase.obtener_habilidades(self.nivel)
            self.vida_max += RECUPERACION_POR_NIVEL
            self.vida = self.vida_max
            self.mana_max += RECUPERACION_POR_NIVEL
            self.mana = self.mana_max
            print(f"¡Has subido al nivel {self.nivel}! Vida y Maná aumentados.")

    def curar(self, cantidad):
        self.vida = min(self.vida + cantidad, self.vida_max)
    def recuperar_mana(self, cantidad):
        self.mana = min(self.mana + cantidad, self.mana_max)
    def recibir_dano(self, cantidad):
        if hasattr(self, "invencible") and self.invencible:
            print("[DEBUG] Eres invencible. Ignoras el daño.")
            return
        self.vida -= cantidad
        if self.vida < 0:
            self.vida = 0
    def esta_vivo(self):
        return self.vida > 0
    def agregar_arma(self, arma):
        if arma.clase_permitida and self.clase.nombre.lower() in arma.clase_permitida:
            self.armas.append(arma)
            print(f"Has obtenido el arma: {arma.nombre}")
        else:
            print(f"No puedes usar el arma {arma.nombre} con tu clase.")
    def mostrar_mochila(self):
        print("\n--- Mochila (Armas) ---")
        if not self.armas:
            print("Vacía")
        else:
            for i, arma in enumerate(self.armas, 1):
                print(f"{i}. {arma}")
        print("\n--- Inventario (Objetos) ---")
        if not self.inventario:
            print("Vacío")
        else:
            for i, obj in enumerate(self.inventario, 1):
                print(f"{i}. {obj.nombre}")

class PersonajeHeroe(Personaje, LogroMixin):
    def __init__(self, nombre, raza_obj, clase_obj):
        Personaje.__init__(self, nombre, raza_obj, clase_obj)
        LogroMixin.__init__(self)

    def __gt__(self, otro):
        return self.nivel > otro.nivel  # ✅ Sobrecarga del operador >
    
class InspectorDePersonaje(Personaje):
    def mostrar_informacion(self):
        print(f"[Público] Vida: {self.vida}")
        print(f"[Protegido] XP: {self._xp}")
        try:
            print(f"[Privado] Oro: {self.__oro}")
        except AttributeError:
            print("[Privado] Oro: No se puede acceder directamente (es privado)")
        print(f"[Privado con name mangling] Oro accedido: {self._Personaje__oro}")

# === CLASES RESTANTES ===
class Clase:
    def __init__(self, nombre, habilidades):
        self.nombre = nombre
        self.habilidades_base = habilidades
    def obtener_habilidades(self, nivel):
        habilidades = {}
        for nombre, req in self.habilidades_base.items():
            if nivel >= req:
                habilidades[nombre] = f"Disponible desde nivel {req}"
        return habilidades

class Objeto:
    def __init__(self, nombre, descripcion, efecto):
        self.nombre = nombre
        self.descripcion = descripcion
        self.efecto = efecto
    def usar(self, personaje):
        print(f"Usas {self.nombre}: {self.descripcion}")
        self.efecto(personaje)

class Arma:
    def __init__(self, nombre, tipo, clase_permitida, danio_min, danio_max):
        self.nombre = nombre
        self.tipo = tipo
        self.clase_permitida = clase_permitida
        self.danio_min = danio_min
        self.danio_max = danio_max
    def obtener_danio(self):
        return random.randint(self.danio_min, self.danio_max)
    def __str__(self):
        return f"{self.nombre} ({self.tipo}, Daño: {self.danio_min}-{self.danio_max})"

class Enemigo:
    def __init__(self, nombre, vida, dano, xp, es_jefe=False):
        self.nombre = nombre
        self.vida = vida
        self.vida_max = vida
        self.dano = dano
        self.xp = xp
        self.es_jefe = es_jefe
    def esta_vivo(self):
        return self.vida > 0
    def recibir_dano(self, cantidad):
        self.vida -= cantidad
        if self.vida < 0:
            self.vida = 0
    def atacar(self, jugador):
        danio_real = random.randint(self.dano - 3, self.dano + 3)
        print(f"{self.nombre} ataca causando {danio_real} de daño.")
        jugador.recibir_dano(danio_real)

class MiembroGremio:
    def __init__(self, nombre, nivel):
        self.nombre = nombre
        self.nivel = nivel
    def __str__(self):
        return f"{self.nombre} (Nv {self.nivel})"

class Gremio:
    def __init__(self):
        self.miembros = []
    def reclutar(self, miembro):
        self.miembros.append(miembro)
        print(f"Has reclutado a {miembro.nombre} (Nv {miembro.nivel}) en tu gremio.")
    def expulsar(self, nombre):
        for m in self.miembros:
            if m.nombre.lower() == nombre.lower():
                self.miembros.remove(m)
                print(f"Has expulsado a {m.nombre} del gremio.")
                return
        print("No hay miembro con ese nombre en tu gremio.")
    def mostrar(self):
        print("\n--- Miembros del Gremio ---")
        if not self.miembros:
            print("Tu gremio está vacío.")
        else:
            for m in self.miembros:
                print(f"- {m}")

# === LABERINTO CON WASD ===
class Laberinto:
    def __init__(self, nombre_area, piso_actual):
        self.nombre_area = nombre_area
        self.piso_actual = piso_actual
        self.ancho = random.randint(10 + piso_actual, 14 + piso_actual * 2)
        self.alto = random.randint(8 + piso_actual, 12 + piso_actual * 2)
        self.mapa = [['#' for _ in range(self.ancho)] for _ in range(self.alto)]
        self.jugador_pos = (1, 1)
        self.salida_pos = (self.alto - 2, self.ancho - 2)
        self.generar_mapa()

    def generar_mapa(self):
        # Paso 1: Rellenar todo con muros por defecto
        for y in range(self.alto):
            for x in range(self.ancho):
                self.mapa[y][x] = '#'

        # Paso 2: Rellenar el interior con caminos, con 85% de probabilidad de ser transitable
        for y in range(1, self.alto - 1):
            for x in range(1, self.ancho - 1):
                self.mapa[y][x] = ' ' if random.random() < 0.85 else '#'

        # Paso 3: Crear un camino garantizado desde jugador a la salida
        y, x = self.jugador_pos
        while y < self.salida_pos[0]:
            y += 1
            self.mapa[y][x] = ' '
        while x < self.salida_pos[1]:
            x += 1
            self.mapa[y][x] = ' '

        # Paso 4: Colocar jugador y salida
        self.mapa[self.jugador_pos[0]][self.jugador_pos[1]] = 'P'
        self.mapa[self.salida_pos[0]][self.salida_pos[1]] = 'S'

        # Paso 5: Agregar trampas en celdas transitables
        for _ in range(random.randint(2, 4)):
            while True:
                ty, tx = random.randint(1, self.alto - 2), random.randint(1, self.ancho - 2)
                if self.mapa[ty][tx] == ' ':
                    self.mapa[ty][tx] = 'T'
                    break

        # Paso 6: Agregar enemigos en celdas transitables
        for _ in range(random.randint(3, 6)):
            while True:
                ey, ex = random.randint(1, self.alto - 2), random.randint(1, self.ancho - 2)
                if self.mapa[ey][ex] == ' ':
                    self.mapa[ey][ex] = 'E'
                    break
    def mostrar(self):  # ✅ Este método es necesario
        print(f"\nÁrea: {self.nombre_area.title()} | Piso {self.piso_actual}")
        for fila in self.mapa:
            print(''.join(fila))

# === HISTORIA ===
class Historia:
    def __init__(self):
        self.areas_visitadas = {}
    def registrar_visita(self, area):
        if area not in self.areas_visitadas:
            self.areas_visitadas[area] = True
            self.evento_area(area)
    def evento_area(self, area):
        print(f"\nAl entrar por primera vez en {area.title()}, un evento único ocurre...")
        if area == "bosque":
            print("El Bosque susurra secretos antiguos entre los árboles.")
        elif area == "mazmorra":
            print("Las sombras parecen moverse por sí solas.")
        elif area == "fortaleza":
            print("La Fortaleza retumba con ecos de batallas.")
        elif area == "archivos":
            print("Verdades prohibidas acechan en los estantes.")
        elif area == "parroquia":
            print("Cánticos rotos resuenan bajo techos agrietados.")
        esperar_tecla()
    def todas_completadas(self):
        return len(self.areas_visitadas) >= 5

# === COMBATE AVANZADO ===
def combate(jugador, enemigo):
    print(f"\n¡Te enfrentas a {enemigo.nombre} (Vida: {enemigo.vida}/{enemigo.vida_max})!")
    while enemigo.esta_vivo() and jugador.esta_vivo():
        print(f"\n{jugador.nombre} (Vida: {jugador.vida}/{jugador.vida_max}, Maná: {jugador.mana}/{jugador.mana_max})")
        print(f"{enemigo.nombre} (Vida: {enemigo.vida}/{enemigo.vida_max})")
        print("1. Atacar con arma\n2. Usar habilidad\n3. Beber poción\n4. Huir")
        accion = input("> ")
        if accion == "1":
            if jugador.armas:
                arma = jugador.armas[0]
                danio = arma.obtener_danio()
                print(f"Atacas con {arma.nombre}, infliges {danio} de daño.")
                enemigo.recibir_dano(danio)
            else:
                print("¡No tienes armas!")
        elif accion == "2":
            if jugador.habilidades:
                print("\n--- Habilidades disponibles ---")
                habilidades_lista = list(jugador.habilidades.items())
                for i, (nombre, desc) in enumerate(habilidades_lista, 1):
                    print(f"{i}. {nombre} - {desc}")
                eleccion = input("Elige una habilidad > ")
                if eleccion.isdigit() and 1 <= int(eleccion) <= len(habilidades_lista):
                    habilidad = habilidades_lista[int(eleccion)-1][0]
                    costo_mana = 10
                    if jugador.mana >= costo_mana:
                        jugador.mana -= costo_mana
                        danio = random.randint(15, 25) + jugador.nivel
                        print(f"Usas {habilidad}, infliges {danio} de daño mágico.")
                        enemigo.recibir_dano(danio)
                    else:
                        print("No tienes suficiente maná.")
                else:
                    print("Selección inválida.")
            else:
                print("Aún no tienes habilidades desbloqueadas.")
        elif accion == "3":
            if jugador.inventario:
                objeto = jugador.inventario.pop(0)
                objeto.usar(jugador)
            else:
                print("No tienes pociones.")
        elif accion == "4":
            print("¡Escapas del combate!")
            return False
        else:
            print("Opción inválida.")
        if enemigo.esta_vivo():
            enemigo.atacar(jugador)
    if not jugador.esta_vivo():
        print(f"¡Has sido derrotado por {enemigo.nombre}!")
        jugador.muertes += 1
        jugador.vida = jugador.vida_max // 2
        jugador.mana = jugador.mana_max // 2
        return False
    elif not enemigo.esta_vivo():
        print(f"¡Has derrotado a {enemigo.nombre}!")
        jugador.ganar_xp(enemigo.xp)
        drop_aleatorio(jugador, enemigo)
        return True

def drop_aleatorio(jugador, enemigo):
    prob = random.random()
    if prob < 0.3:
        efecto_pocion = lambda p: p.curar(30)
        pocion = Objeto("Poción de Vida", "Cura 30 puntos de vida.", efecto_pocion)
        jugador.inventario.append(pocion)
        print(f"{enemigo.nombre} soltó una Poción de Vida.")
    elif prob < 0.6:
        tipos = ["espada", "hacha", "bastón"]
        tipo = random.choice(tipos)
        clase_permitida = ["guerrero"] if tipo in ["espada", "hacha"] else ["mago"]
        danio_min = random.randint(5, 10) + jugador.nivel // 3
        danio_max = danio_min + random.randint(5, 10)
        arma = Arma(f"{tipo.capitalize()} misteriosa", tipo, clase_permitida, danio_min, danio_max)
        jugador.agregar_arma(arma)
    else:
        oro_encontrado = random.randint(10, 30) + enemigo.xp // 2
        jugador.oro += oro_encontrado
        print(f"Encuentras {oro_encontrado} monedas de oro.")

# === AQUÍ SIGUE exploración WASD, ciudadela, main, etc. ===
# === EXPLORACIÓN CON WASD ===
def explorar_area(jugador, area, historia):
    piso_actual = 1
    while piso_actual <= PISOS_POR_AREA:
        lab = Laberinto(area, piso_actual)

        while True:
            limpiar_pantalla()
            lab.mostrar()
            print(f"\n{jugador.nombre} | Vida: {jugador.vida}/{jugador.vida_max} | Maná: {jugador.mana}/{jugador.mana_max} | Oro: {jugador.oro}")
            print("Usa W/A/S/D para moverte. (Q para regresar a la Ciudadela)")
            mov = input("> ").lower()

            y, x = lab.jugador_pos
            ny, nx = y, x

            if mov == "w" and y > 1:
                ny -= 1
            elif mov == "s" and y < lab.alto - 2:
                ny += 1
            elif mov == "a" and x > 1:
                nx -= 1
            elif mov == "d" and x < lab.ancho - 2:
                nx += 1
            elif mov == "q":
                print("Regresas a la Ciudadela.")
                return
            else:
                continue

            celda = lab.mapa[ny][nx]

            # Solo moverse si la celda no es una pared
            if celda not in [' ', 'E', 'T', 'S']:
                continue  # Si es muro u otra cosa, no moverse

            # Restaurar la celda anterior si era la salida
            if (y, x) == lab.salida_pos:
                lab.mapa[y][x] = 'S'
            else:
                lab.mapa[y][x] = ' '

            # Mover al jugador
            lab.jugador_pos = (ny, nx)
            lab.mapa[ny][nx] = 'P'
            
            if celda == 'E':
                nivel = piso_actual + random.randint(0, jugador.nivel)
                vida = 30 + nivel * 5
                dano = 5 + nivel * 2
                xp = 10 + nivel * 3
                enemigo = Enemigo(f"{area.title()} bestia Nv{nivel}", vida, dano, xp)
                sobreviviste = combate(jugador, enemigo)
                if not sobreviviste:
                    print("Regresas malherido a la Ciudadela.")
                    return
            elif celda == 'T':
                dano_trampa = random.randint(5, 15)
                jugador.recibir_dano(dano_trampa)
                print(f"\n¡Has activado una trampa! Pierdes {dano_trampa} de vida.")
                if not jugador.esta_vivo():
                    print("La trampa fue letal. Despiertas herido en la Ciudadela.")
                    jugador.muertes += 1
                    jugador.vida = jugador.vida_max // 2
                    jugador.mana = jugador.mana_max // 2
                    return
                esperar_tecla()
            elif celda == 'S':
                print(f"\n[+] ¡Has encontrado la salida del piso {piso_actual}!")
                esperar_tecla()
                piso_actual += 1
                break

        # Mini-jefe
        if piso_actual == PISOS_POR_AREA // 2:
            jefe = Enemigo(f"Guardia de {area.title()}", 80 + jugador.nivel*4, 15 + jugador.nivel//2, 50)
            print(f"\n¡Un mini-jefe bloquea tu camino!")
            sobreviviste = combate(jugador, jefe)
            if not sobreviviste or not jugador.esta_vivo():
                print("Escapas herido hacia la Ciudadela...")
                return

        # Jefe final
        if piso_actual > PISOS_POR_AREA:
            jefe_final_area = Enemigo(f"Señor de {area.title()}", 120 + jugador.nivel*5, 18 + jugador.nivel//2, 100, es_jefe=True)
            print(f"\n¡Llegas al corazón de {area.title()}! Enfrentas al jefe final.")
            sobreviviste = combate(jugador, jefe_final_area)
            if not sobreviviste or not jugador.esta_vivo():
                print("Apenas sobrevives y regresas arrastrándote a la Ciudadela...")
                return
            print(f"\n¡Has completado toda la exploración del área {area.title()}!")
            esperar_tecla()
            return

# === CIUDADELA ===
def ciudadela(jugador, gremio):
    while True:
        print("\n--- Ciudadela ---")
        print("1. Descansar\n2. Comerciar\n3. Gestionar el gremio\n4. Ver logros\n5. Salir de la Ciudadela")
        opcion = input("> ")
        if opcion == "1":
            jugador.vida = jugador.vida_max
            jugador.mana = jugador.mana_max
            print("Descansas y recuperas totalmente.")
        elif opcion == "2":
            comerciar(jugador)
        elif opcion == "3":
            gestionar_gremio(jugador, gremio)
        elif opcion == "4":
            jugador.mostrar_logros()
        elif opcion == "5":
            break
        else:
            print("Opción inválida.")

def comerciar(jugador):
    while True:
        print("\n--- Comercio ---")
        print(f"Tienes {jugador.oro} monedas de oro.")
        print("1. Comprar poción de vida (30 oro)\n2. Salir")
        opcion = input("> ")
        if opcion == "1":
            if jugador.oro >= 30:
                efecto_pocion = lambda p: p.curar(30)
                pocion = Objeto("Poción de Vida", "Cura 30 puntos.", efecto_pocion)
                jugador.inventario.append(pocion)
                jugador.oro -= 30
                print("Compraste una Poción de Vida.")
            else:
                print("No tienes suficiente oro.")
        elif opcion == "2":
            break
        else:
            print("Opción inválida.")

def gestionar_gremio(jugador, gremio):
    while True:
        print("\n--- Gestión del Gremio ---")
        print("1. Ver miembros\n2. Reclutar nuevo miembro\n3. Expulsar miembro\n4. Volver")
        eleccion = input("> ")
        if eleccion == "1":
            gremio.mostrar()
        elif eleccion == "2":
            nombres = ["Einar", "Lyra", "Thorn", "Seraphine", "Doran", "Kael"]
            nuevo = MiembroGremio(random.choice(nombres)+str(random.randint(1,99)), random.randint(1, jugador.nivel))
            gremio.reclutar(nuevo)
        elif eleccion == "3":
            nombre_expulsar = input("Nombre del miembro a expulsar: ")
            gremio.expulsar(nombre_expulsar)
        elif eleccion == "4":
            break
        else:
            print("Opción inválida.")

# === FINAL MULTIFINALES ===
def jefe_final(jugador, gremio, historia):
    print("\nEl Rey Ornstein te espera en la cúspide del mundo...")
    ornstein = Enemigo("Rey Ornstein", 160 + jugador.nivel*4, 15 + jugador.nivel//3, 250, es_jefe=True)
    sobreviviste = combate(jugador, ornstein)

    if not sobreviviste or not jugador.esta_vivo():
        print("Ornstein te derrota y la oscuridad consume el mundo...")
        esperar_tecla()  # pausa antes de salir
        sys.exit()
    
    determinar_final(jugador, gremio, historia)
    esperar_tecla()  # pausa también después de la victoria
    sys.exit()

def determinar_final(jugador, gremio, historia):
    print("\n--- Epílogo ---")
    if jugador.muertes >= 3:
        print("Tantas muertes corrompieron tu alma. Salvas el mundo, pero te conviertes en sombra.")
    elif len(gremio.miembros) >= 5:
        print("Con tu poderoso gremio fundas un reino. La paz llega, bajo tu implacable estandarte.")
    elif jugador.muertes == 0 and jugador.vida > jugador.vida_max * 0.8:
        print("Eres el héroe de la profecía. El mundo florece y tu leyenda vive por siempre.")
    else:
        print("Traes equilibrio, pero las cicatrices del mundo permanecerán por siempre.")
    print("\n¡Gracias por jugar Leyends Of The Lost Heroes!")

def activar_debug(jugador, historia, gremio):
    print("\n*** MODO DEBUG SECRETO ACTIVADO ***")
    while True:
        print("\nOpciones de Debug:")
        print("1. Subir niveles")
        print("2. Restaurar vida y maná")
        print("3. Añadir oro")
        print("4. Añadir arma")
        print("5. Añadir poción")
        print("6. Ver/modificar estadísticas")
        print("7. Activar/Desactivar invencibilidad")
        print("8. Saltar al jefe final")
        print("9. Desbloquear todas las áreas")
        print("10. Salir del modo debug")
        print("11. Probar patrones OOP avanzados")
        opcion = input("DEBUG > ")

        if opcion == "1":
            niveles = int(input("¿Cuántos niveles quieres subir? > "))
            jugador.ganar_xp(jugador.nivel * 20 * niveles)
        elif opcion == "2":
            jugador.vida = jugador.vida_max
            jugador.mana = jugador.mana_max
            print("Vida y maná restaurados.")
        elif opcion == "3":
            oro = int(input("¿Cuánto oro quieres añadir? > "))
            jugador.oro += oro
            print(f"Se añadieron {oro} monedas de oro.")
        elif opcion == "4":
            nombre = input("Nombre del arma > ")
            tipo = input("Tipo (espada/hacha/bastón) > ")
            clase = input("Clase permitida (guerrero/mago) > ").lower()
            dmin = int(input("Daño mínimo > "))
            dmax = int(input("Daño máximo > "))
            arma = Arma(nombre, tipo, [clase], dmin, dmax)
            jugador.agregar_arma(arma)
        elif opcion == "5":
            efecto_pocion = lambda p: p.curar(999)
            pocion = Objeto("MegaPoción", "Restaura toda la vida.", efecto_pocion)
            jugador.inventario.append(pocion)
            print("Se añadió una MegaPoción al inventario.")
        elif opcion == "6":
            print(f"Nivel: {jugador.nivel}, XP: {jugador.xp}, Muertes: {jugador.muertes}, Vida: {jugador.vida}/{jugador.vida_max}")
            stat = input("¿Qué deseas modificar? (nivel/xp/vida/muertes/ninguno) > ").lower()
            if stat == "nivel":
                jugador.nivel = int(input("Nuevo nivel > "))
            elif stat == "xp":
                jugador.xp = int(input("Nuevo XP > "))
            elif stat == "vida":
                jugador.vida = int(input("Nueva vida > "))
            elif stat == "muertes":
                jugador.muertes = int(input("Número de muertes > "))
        elif opcion == "7":
            jugador.invencible = not jugador.invencible
            estado = "ACTIVADO" if jugador.invencible else "DESACTIVADO"
            print(f"Modo invencible: {estado}")
        elif opcion == "8":
            print("Saltando directamente al jefe final...")
            jefe_final(jugador, gremio, historia)
            break
        elif opcion == "9":
            for area in ["bosque", "mazmorra", "fortaleza", "archivos", "parroquia"]:
                historia.registrar_visita(area)
            print("Todas las áreas marcadas como completadas.")
        elif opcion == "10":
            print("Saliendo del modo debug...")
            break
        elif opcion == "11":
            print("\n=== PRUEBA DE PATRONES OOP AVANZADOS ===")
            print(f"Personajes creados: {Personaje.contador_personajes}")
            inspector = InspectorDePersonaje(jugador.nombre, jugador.raza, jugador.clase)
            inspector.mostrar_informacion()
            dummy = PersonajeHeroe("Dummy", Humano(), Clase("Guerrero", {}))
            if jugador > dummy:
                print(f"{jugador.nombre} tiene más nivel que Dummy.")
            else:
                print(f"{jugador.nombre} NO tiene más nivel que Dummy.")
        else:
            print("Opción inválida.")

# === MAIN ===
def main():
    limpiar_pantalla()
    imprimir_ascii_art("Bienvenido a Leyends Of The Lost Heroes")
    nombre = input("¿Cuál es tu nombre, aventurero? > ")
    debug_mode = False
    if nombre == "V0RT3X" and input("¿Tienes un código? > ") == "X9-Ω-D347H":
        debug_mode = True

    # Elegir raza
    while True:
        print("\nElige tu raza:\n1. Humano\n2. Elfo\n3. Enano")
        r = input("> ")
        if r == "1": raza = Humano(); break
        elif r == "2": raza = Elfo(); break
        elif r == "3": raza = Enano(); break
        else: print("Opción inválida.")

    # Elegir clase
    while True:
        print("\nElige tu clase:\n1. Guerrero\n2. Mago")
        c = input("> ")
        if c == "1": clase = Clase("Guerrero", {"Golpe Poderoso": 1, "Torbellino":10}); break
        elif c == "2": clase = Clase("Mago", {"Bola de Fuego":1, "Tormenta Arcana":10}); break
        else: print("Opción inválida.")

    jugador = PersonajeHeroe(nombre, raza, clase)
    historia = Historia()
    gremio = Gremio()
    if debug_mode:
        activar_debug(jugador, historia, gremio)

    # Arma inicial
    if clase.nombre.lower() == "guerrero":
        jugador.agregar_arma(Arma("Espada Oxidada", "espada", ["guerrero"], 5, 10))
    elif clase.nombre.lower() == "mago":
        jugador.agregar_arma(Arma("Bastón Usado", "bastón", ["mago"], 4, 9))
    print(f"Has recibido tu {jugador.armas[0].nombre} para comenzar.")

    # Menú principal
    areas = ["bosque", "mazmorra", "fortaleza", "archivos", "parroquia"]
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Explorar un área\n2. Ir a la Ciudadela\n3. Ver mochila\n4. Salir")
        op = input("> ")
        if op == "1":
            print("\nÁreas disponibles:")
            for i, a in enumerate(areas,1): print(f"{i}. {a.title()}")
            e = input("Elige un área por número: ")
            if e.isdigit() and 1 <= int(e) <= len(areas):
                area = areas[int(e)-1]
                historia.registrar_visita(area)
                explorar_area(jugador, area, historia)
            else:
                print("Selección inválida.")
        elif op == "2":
            ciudadela(jugador, gremio)
        elif op == "3":
            jugador.mostrar_mochila()
        elif op == "4":
            print("¡Hasta pronto, aventurero!")
            break
        else:
            print("Opción inválida.")
        if historia.todas_completadas():
            jefe_final(jugador, gremio, historia)
            break

# === EJECUTAR ===
if __name__ == "__main__":
    main()
