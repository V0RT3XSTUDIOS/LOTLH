=============================================
     README - Leyends Of The Lost Heroes
=============================================

>> Información General:
Título del juego: Leyends Of The Lost Heroes v1.7
Versión: 1.0  
Autor: Diego Abimael Hernandez Moreno "V0RT3X" / Rodrigo Jesus Serrano Garcia "R0y"  
Lenguaje: Python 3.x  
Dependencias: Librerías estándar de Python (os, random, time, sys)

---------------------------------------------
>> Instrucciones de Ejecución:
1. Asegúrate de tener Python instalado (3.8 o superior).
2. Ejecuta el archivo LOTLH.py desde tu terminal o IDE.
   > python LOTLH.py
3. Sigue las instrucciones en pantalla para crear tu personaje y comenzar la aventura.

---------------------------------------------
>> Descripción Técnica:
- Juego RPG por consola con exploración tipo laberinto (WASD).
- Sistema de combate con habilidades, armas y enemigos con IA básica.
- Narrativa ramificada y múltiples finales según decisiones del jugador.
- Sistema de niveles, evolución racial, clases, inventario y gremio.
- Laberintos generados proceduralmente con trampas y enemigos.
- Mini-jefes y jefes por área.
- Ciudadela con mercado y gestión de gremio.
- Modo DEBUG activable con código secreto.

---------------------------------------------
>> Credenciales del MODO DEBUG:
Nombre de personaje: V0RT3X 
Código de acceso: X9-Ω-D347H

>> Acciones disponibles en el modo DEBUG:
1. Subir niveles manualmente
2. Restaurar vida y maná
3. Añadir oro
4. Crear armas personalizadas
5. Obtener pociones especiales
6. Modificar estadísticas
7. Activar/desactivar invencibilidad
8. Ir directamente al jefe final
9. Desbloquear todas las áreas
10. Probar patrones OOP avanzados

**Nota:** Este modo está diseñado para pruebas internas y no se recomienda usarlo en una partida normal.

---------------------------------------------
>> Notas Finales:
- El juego guarda el estado solo en memoria.
- No requiere conexión a internet.
- Puede ampliarse para guardar partidas y usar archivos externos.
- Compatible con Windows, macOS y Linux.

¡Gracias por jugar y disfrutar Leyends Of The Lost Heroes!
